#include <time.h>		// time
#include <stdlib.h>		// srand
#include <math.h>		// standard C <math.h> sin, cos

#include "math.h"

// pre-calculated cos/sin table
float psin[360];
float pcos[360];

void MathInit (void)
{
	// randomize
	srand(time(0));

	CreateTrig();
}

void CreateTrig (void)
{
	for (int ang = 0; ang < 360; ang++)
	{
		float t = (float)ang*(float)PI/180.0f;
		pcos[ang] = (float)cos(t);
		psin[ang] = (float)sin(t);
	}
}

// rotates a point at x,y CW or CCW around local (0, 0) coordinates
void rotatef (float &p1, float &p2, int deg)
{
	if (deg == 0)
		return;

	if (deg < 0)
		deg = 360 + deg;

	//rotate
	float rp1 = pcos[deg] * p1 - psin[deg] * p2;
	float rp2 = psin[deg] * p1 + pcos[deg] * p2;

	p1 = rp1;
	p2 = rp2;
}
