 THE PIXELS TUTORIALS
 www.thepixels.net
 by: Greg Damon
     gregd@thepixels.net

This tutorial was downloaded from thepixels.net You don't have to give credit to anyone if you're going to use it for your own purposes but if you are, please let me know by contacting me. It's always nice to know if these tutorials has helped someone. Contacting me on this occasion might also help me to write more tutorials.

Greg Damon