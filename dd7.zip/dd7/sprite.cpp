#include <ddraw.h>
#include "sprite.h"

extern LPDIRECTDRAWSURFACE7 lpBackBuffer;
extern LPDIRECTDRAWSURFACE7 extractor;
extern LPDIRECTDRAWSURFACE7 CreateSurface (int width, int height, bool transparent);
 
void BltSprite (SPRITE *sprite, int num, int x, int y)
{
	RECT dstrect = {x, y, x + sprite->width, y + sprite->height};
	lpBackBuffer->Blt(&dstrect, sprite->surface[num], NULL, DDBLT_WAIT, NULL);
}

void BltSpriteT (SPRITE *sprite, int num, int x, int y)
{
	RECT dstrect = {x, y, x + sprite->width, y + sprite->height};
	lpBackBuffer->Blt(&dstrect, sprite->surface[num], NULL, DDBLT_WAIT|DDBLT_KEYSRC, NULL);
}

void CreateSprite (SPRITE *sprite, int num, int width, int height, int x, int y, bool transparent)
{
	sprite->width = width;
	sprite->height = height;

	if (transparent)
	   sprite->transparent = true;

	//NOTE: the value of transparent is not really used in any way in this tutorial
	
	sprite->surface[num] = CreateSurface(width, height, transparent);

	int rectx = x;
	int recty = y;
	int rectw = x + width;
	int recth = y + height;

	RECT srcrect = {rectx, recty, rectw, recth};
	sprite->surface[num]->Blt(NULL, extractor, &srcrect, DDBLT_WAIT, NULL);
}