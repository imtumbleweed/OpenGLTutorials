// OpenGL  base code
// updated: september 2002

// system.h
// from:

// www.thepixels.net
// by:    Greg Damon
//        gregd@thepixels.net
// --------------------------

void SysShutdown (void);			// SysShutdown: shutdowns the application and releases memory
void SysSetDisplayMode (int width, int height, int depth); // SysSetDisplayMode: sets display mode
void SysRecoverDisplayMode (void);	// SysRecoverDisplayMode: switch back to default resolution
