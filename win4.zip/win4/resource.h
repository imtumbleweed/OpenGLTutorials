// resource.h

#define ID_Menu		100
#define ID_Red		0
#define ID_Green	1
#define ID_Blue		2
#define ID_Exit		3

