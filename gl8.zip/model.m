beginmodel 2

-1.0f 0.0f 0.0f   ,   1.0f 0.0f 0.0f    ,   0.0f 1.0f 0.0f    ;initial polygon
-1.0f 0.0f 0.0f   ,   0.0f -1.0f 0.0f   ,  1.0f 0.0f 0.0f     ;2nd
