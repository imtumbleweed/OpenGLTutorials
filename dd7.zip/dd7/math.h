#define PI		3.14159

#define _max(a, b) ((a > b) ? a : b)
#define _min(a, b) ((a < b) ? a : b)

// pre-calculated cos/sin table
extern float psin[360];
extern float pcos[360];

/* 2D Math Functions */

void MathInit (void);
void CreateTrig (void);		// builds the trig cos/sin table

// rotates a (floating) point
void rotatef (float &x, float &y, int deg);
