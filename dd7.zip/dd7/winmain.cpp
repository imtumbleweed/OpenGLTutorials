// THE PIXELS TUTORIALS
// www.thepixels.net
// by: Greg Damon
//     gregd@thepixels.net

#include <windows.h>
#include <ddraw.h>
#include <stdio.h>		// FILE

#include "math.h"
#include "sprite.h"

// 16 bit color macros
#define _15BIT(r,g,b) (((r&248)<<7) + ((g&248)<<2) + (b>>3))
#define _16BIT(r,g,b) (((r&248)<<8) + ((g&252)<<3) + (b>>3))

#define TC16BIT _16BIT(0, 0, 255)

#define WNDCLASSNAME "wndclass"

typedef unsigned short ushort;

HDC hdc;
HWND hwnd;

// generic DirectDraw declarations
DDSURFACEDESC2			ddsd;
LPDIRECTDRAW			lpdd = NULL;
LPDIRECTDRAW7			lpdd7 = NULL;
LPDIRECTDRAWCLIPPER		lpClipper = NULL;
LPDIRECTDRAWSURFACE7	lpPrimary = NULL;
LPDIRECTDRAWSURFACE7	lpBackBuffer = NULL;

// monster data
SPRITE					monster[2];

// used for bitmap data extraction
int						bitmap_width;
int						bitmap_height;
unsigned long		   *bitmap_data = NULL;
LPDIRECTDRAWSURFACE7	extractor = NULL;

// screen dimensions
int swidth = 640;
int sheight = 480;
int sbpp = 16;

// used for accessing surface memory
int lpitch = 0;
ushort *lpscreen = NULL;

// indicates the state of application
bool quit = false;

// Functions ---------------------------------------------------------

// forward declarations
void EraseDesc (void);
void FlipBitmap (int width, int height);
void CopyFromBitmap (LPDIRECTDRAWSURFACE7 surface);
LPDIRECTDRAWSURFACE7 CreateSurface (int width, int height, bool transparent = false);
void ClearSurface (LPDIRECTDRAWSURFACE7 surface, int r, int g, int b);
void ClipSurface(LPDIRECTDRAWSURFACE7 surface, int x, int y, int width, int height);

void InitMonsters (void)
{
	monster[0].x = 32;
	monster[0].y = 0;
	monster[0].width = 128.0f;
	monster[0].height = 96.0f;

	monster[1].x = -32;
	monster[1].y = 0;
	monster[1].width = 96.0f;
	monster[1].height = 128.0f;
}

void SpinMonsters (void)
{
	rotatef(monster[0].x, monster[0].y, 2);
	rotatef(monster[1].x, monster[1].y, 2);
}

void HostFrame (void)
{
	ClearSurface(lpBackBuffer, 0, 0, 0);

	// Rotate monster coordinates for fun
	SpinMonsters();

	// Render sprites to the Back Buffer surface here
	// After translating the local coordinates to center of the screen
	BltSpriteT(&monster[0], 0, 320 + (int)(monster[0].x - monster[0].width / 2), 
							   240 + (int)(monster[0].y - monster[0].height / 2));
	BltSpriteT(&monster[1], 0, 320 + (int)(monster[1].x - monster[1].width / 2),
							   240 + (int)(monster[1].y - monster[1].height / 2));
	
	// flip the backbuffer to primary surface
	lpPrimary->Flip(lpBackBuffer, DDFLIP_WAIT);
}

// 16-bit BITMAP loading function
char *LoadBitmap (char *filename)
{
	FILE *file;
	long offset, width, height, size, bitsize;
	short type, bitcount;

	if (extractor)
	{
	    extractor->Release();
	    extractor = NULL;
	}

	if (bitmap_data)
	{
	    free(bitmap_data);
	    bitmap_data = NULL;
	}
	
	file = fopen(filename, "rb");
	if (!file)
	{
	    fclose(file);
	    return "couldn't open the bitmap file";
	}

	fread(&type, sizeof(short), 1, file);

	// make sure it is a bitmap file
	if (type != 0x4D42)
	{
	    fclose(file);
	    return "bitmap=!0x4d42";
	}

	// read some useful info
	fseek(file, 10, SEEK_SET);
	fread(&offset, sizeof(long), 1, file);
	fseek(file, 4, SEEK_CUR);	
	fread(&width, sizeof(long), 1, file);
	fread(&height, sizeof(long), 1, file);
	fseek(file, 2, SEEK_CUR);
	fread(&bitcount, sizeof(short), 1, file);
	
	if (bitcount != 32)
	{
	    fclose(file);
	    return "bitmap_not32bit";
	}

	// read the size of data in bytes
	fseek(file, 4, SEEK_CUR);
	fread(&size, sizeof(long), 1, file);

	// skip the rest of header and read the bit data
	fseek(file, 16, SEEK_CUR);
	
	size = width * height * 4;
	
	bitmap_data = (unsigned long*)malloc(size);
	
	if (bitmap_data == NULL)
	{
	    fclose(file);
	    return "bitmap_nullmemory";
	}

	bitsize = fread(bitmap_data, 1, size, file);
	
	if (bitsize != size || !bitsize)
	{
	    fclose(file);
	    return "bitmap_badmemory";
	}

	bitmap_width = width;
	bitmap_height = height;

	FlipBitmap(width, height);
	extractor = CreateSurface(width, height);
	CopyFromBitmap(extractor);

	fclose(file);
	return "bitmap_ok";
}

void FlipBitmap (int width, int height)
{
	unsigned long *imgcopy = NULL;

	int byte_width = width * 4;

	int row = 0;
	int bpl = byte_width;
	int size = bpl * height;

	if(!(imgcopy = (unsigned long*)malloc(size)))
		MessageBox(hwnd, "Out of memory", "Memory Error", MB_OK);

	// flip
	do{ int src_addr = row * width;
	    int dst_addr = width * height - row * width - width;
		memcpy(&imgcopy[dst_addr], &bitmap_data[src_addr], byte_width);
		row++;
	} while (row < height);

	memcpy(bitmap_data, imgcopy, size);

	if (imgcopy)
		free(imgcopy);
}

void CopyFromBitmap (LPDIRECTDRAWSURFACE7 surface)
{
	int size = bitmap_width * bitmap_height;
	int widthc = 0;
	int offset = 0;
	unsigned long *ptrBitmap = (unsigned long*)bitmap_data;

	EraseDesc();

	surface->Lock(NULL, &ddsd, DDLOCK_WAIT, NULL);

	lpitch = (int)ddsd.lPitch >> 1;
	lpscreen = (ushort*)ddsd.lpSurface;

	int i = 0;

	int x, y;

	for(y = 0; y < bitmap_height; y++)
	{
	    for(x = 0; x < bitmap_width; x++, i++)
	    {
			// convert from 32 to 16 bit
			int r = (ptrBitmap[i] >> 16) & 0xff;
			int g = (ptrBitmap[i] >> 8) & 0xff;
			int b = ptrBitmap[i] & 0xff;

			lpscreen[x + y * lpitch] = _16BIT(r, g, b);
	    }
	}

	surface->Unlock(NULL);
}

void LoadGraphics (void)
{
	char buffer[256];
	
	strcpy(buffer, LoadBitmap("monster.bmp"));

	if (strcmp(buffer, "bitmap_ok") != 0)
		MessageBox(hwnd, buffer, "File Error", MB_OK);
	
	CreateSprite(&monster[0], 0, bitmap_width, bitmap_height, 0, 0, true);
	CreateSprite(&monster[1], 0, bitmap_width, bitmap_height, 0, 0, true);
}

//*=====================
//  Direct draw
//*=====================

void EraseDesc (void)
{
	memset(&ddsd, 0, sizeof(DDSURFACEDESC2));
	ddsd.dwSize = sizeof(DDSURFACEDESC2);
}

void DirectDrawRelease (void)
{
	if (lpClipper)
	{
		lpClipper->Release();
		lpClipper = NULL;
	}

	if (lpBackBuffer)
	{
		lpBackBuffer->Release();
		lpBackBuffer = NULL;
	}

	if (lpPrimary)
	{
		lpPrimary->Release();
		lpPrimary = NULL;
	}

	if (lpdd7)
	{
		lpdd7->Release();
		lpdd7 = NULL;
	}
}

void DirectDrawInit (void)
{
	long rval;
	
	rval = DirectDrawCreate(NULL, &lpdd, NULL);

	if (rval != DD_OK)
	{
		MessageBox(hwnd, "Failed to create the DirectDraw object", "Error", MB_OK);
		quit = true;
	}
	
	rval = lpdd->QueryInterface(IID_IDirectDraw7, (LPVOID*)&lpdd7);

	if (rval != DD_OK)
	{
		MessageBox(hwnd, "Failed to query interface for DirectDraw7", "Error", MB_OK);
		quit = true;
	}
	
	if (lpdd)
	{
		lpdd->Release();
		lpdd = NULL;
	}
	
	rval = lpdd7->SetCooperativeLevel(hwnd, DDSCL_FULLSCREEN|DDSCL_EXCLUSIVE|DDSCL_ALLOWREBOOT);

	if (rval != DD_OK)
	{
		MessageBox(hwnd, "Failed to set DirectDraw cooperative level", "Error", MB_OK);
		quit = true;
	}
	
	rval = lpdd7->SetDisplayMode(swidth, sheight, sbpp, 0, 0);

	if (rval != DD_OK)
	{
		MessageBox(hwnd, "Failed to set display mode", "Error", MB_OK);
		quit = true;
	}

	EraseDesc();
	
	// set appropriate flags for creating the primary surface
	ddsd.dwFlags = DDSD_CAPS|DDSD_BACKBUFFERCOUNT;
	ddsd.dwBackBufferCount = 1;
	ddsd.ddsCaps.dwCaps = DDSCAPS_PRIMARYSURFACE|DDSCAPS_COMPLEX|DDSCAPS_FLIP;
	
	rval = lpdd7->CreateSurface(&ddsd, &lpPrimary, NULL);
		
	if (rval != DD_OK)
	{
		MessageBox(hwnd, "Failed to create the primary surface", "Error", MB_OK);
		quit = true;
	}

	ddsd.ddsCaps.dwCaps = DDSCAPS_BACKBUFFER;

	rval = lpPrimary->GetAttachedSurface(&ddsd.ddsCaps, &lpBackBuffer);

	if(rval != DD_OK)
		quit = true; // Failed to create and attach the Back Buffer

	ClipSurface(lpBackBuffer, 0, 0, 640, 480);	
}

void ClearSurface (LPDIRECTDRAWSURFACE7 surface, int r, int g, int b)
{
	DDBLTFX fx;

	memset(&fx, 0, sizeof(fx));
	fx.dwSize = sizeof(fx);
	fx.dwFillColor = _16BIT(r, g, b);

	surface->Blt(NULL, NULL, NULL, DDBLT_COLORFILL|DDBLT_WAIT, &fx);
}

LPDIRECTDRAWSURFACE7 CreateSurface (int width, int height, bool transparent)
{
	DDCOLORKEY				ck;
	LPDIRECTDRAWSURFACE7	surface = NULL;

	// NOTE: parameter transparent is not used in this tutorial.

	// Clear the ddsd memory
	EraseDesc();

	if (transparent)
		ddsd.dwFlags = DDSD_CAPS|DDSD_WIDTH|DDSD_HEIGHT|DDSD_CKSRCBLT;
	else
		ddsd.dwFlags = DDSD_CAPS|DDSD_WIDTH|DDSD_HEIGHT;

	// Fill in the surface info
	ddsd.dwFlags = DDSD_CAPS|DDSD_WIDTH|DDSD_HEIGHT;
	ddsd.dwWidth = width;
	ddsd.dwHeight = height;
	ddsd.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN|DDSCAPS_VIDEOMEMORY;

	// Create the surface
	long rval = lpdd7->CreateSurface(&ddsd, &surface, NULL);

	if (transparent)
	{
	    ck.dwColorSpaceLowValue = TC16BIT;
	    ck.dwColorSpaceHighValue = TC16BIT;
		surface->SetColorKey(DDCKEY_SRCBLT, &ck);
	}

	if (rval != DD_OK)
	   MessageBox(hwnd, "Failed to create an offscreen surface", "Surface Error", MB_OK);	   

	return surface;
}

void ClipSurface(LPDIRECTDRAWSURFACE7 surface, int x, int y, int width, int height)
{
	LPRGNDATA rd;
	RECT cliprect = {x, y, width, height};

	long rval;

	if ((rval = lpdd7->CreateClipper(0, &lpClipper, NULL) != DD_OK))
	{
		DirectDrawRelease();
		exit(1); // Failed to create clipper
	}

	rd = (LPRGNDATA)malloc(sizeof(RGNDATAHEADER) + sizeof(RECT));
	memcpy(rd->Buffer, &cliprect, sizeof(RECT));

	rd->rdh.dwSize = sizeof(RGNDATAHEADER);
	rd->rdh.iType = RDH_RECTANGLES;
	rd->rdh.nCount = 1;
	rd->rdh.nRgnSize = sizeof(RECT);
	rd->rdh.rcBound.left = x;
	rd->rdh.rcBound.right = x+width;
	rd->rdh.rcBound.top = y;
	rd->rdh.rcBound.bottom = y+height;

	rval = lpClipper->SetClipList(rd, 0);
	if(rval != DD_OK)
	{
		if (rd) free(rd);

		DirectDrawRelease();
		exit(1); // Failed to SetClipList
	}
	
	rval = surface->SetClipper(lpClipper);
	if(rval != DD_OK)
	{
		if (rd) free(rd);

		DirectDrawRelease();
		exit(1); // Failed to SetClipper
	}

	if (rd) free(rd);
}

void LockSurface (LPDIRECTDRAWSURFACE7 surface)
{
	EraseDesc();
	
	if ((surface->Lock(NULL, &ddsd, DDLOCK_WAIT, NULL)) != DD_OK)
		MessageBox(hwnd, "Failed to lock the surface", "Surface Error", MB_OK);

	lpitch = (int)ddsd.lPitch;
	lpscreen = (ushort*)ddsd.lpSurface;
}

void UnlockSurface (LPDIRECTDRAWSURFACE7 surface)
{
	surface->Unlock(NULL);
	
	lpitch = 0;
	lpscreen = NULL;
}

void Pixel (int x, int y, ushort color)
{
	lpscreen[x + y * (lpitch >> 1)] = color;
}

//*=====================
//  The event handler
//*=====================

LRESULT CALLBACK WinProc (HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam)
{
	switch(msg)
	{
	case WM_CLOSE:
		{
			PostQuitMessage(0);
			break;
		}
	}
	return DefWindowProc(hwnd, msg, wparam, lparam);
}

//*=====================
//  WinMain
//*=====================

int WINAPI WinMain (HINSTANCE hinstance,
		   HINSTANCE hprevinstance,
		   LPSTR lpcmdline,
		   int nshowcmd)
{
	MSG msg;
	WNDCLASSEX ex;

	ex.cbSize = sizeof(WNDCLASSEX);
	ex.style = CS_HREDRAW|CS_VREDRAW|CS_OWNDC;
	ex.lpfnWndProc = WinProc;
	ex.cbClsExtra = 0;
	ex.cbWndExtra = 0;
	ex.hInstance = hinstance;
	ex.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	ex.hCursor = LoadCursor(NULL, IDC_ARROW);
	ex.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
	ex.lpszMenuName = NULL;
	ex.lpszClassName = WNDCLASSNAME;
	ex.hIconSm = NULL;

	RegisterClassEx(&ex);

	// create the window
	hwnd = CreateWindowEx(NULL,
 			      WNDCLASSNAME,
			      "Window",
			      WS_POPUP,
			      0, 0,
			      300, 300,
			      NULL,
			      NULL,
			      hinstance,
			      NULL);

	ShowWindow(hwnd, SW_SHOW);
	UpdateWindow(hwnd);

	// init direct draw
	DirectDrawInit();

	// init trig. table
	MathInit();

	// load monsters onto surfaces (in sprites: monster[0] & monster[1])
	LoadGraphics();

	// init monsters' coordinates
	InitMonsters();

	// the message loop
	while (!quit)
	{
		if (PeekMessage(&msg, NULL, NULL, NULL, PM_REMOVE))
		{
			if (msg.message == WM_QUIT || GetAsyncKeyState(VK_ESCAPE))
				quit = true;

			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}

		HostFrame();
	}

	if (bitmap_data)
		free(bitmap_data);

	// release directdraw memory and destroy the dd object
	DirectDrawRelease();

	return msg.lParam;
}
