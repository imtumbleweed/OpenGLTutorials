// OpenGL  base code
// updated: september 2002

// system.cpp - system code; shutdown, release memory, system misc.
// from:

// www.thepixels.net
// by:    Greg Damon
//        gregd@thepixels.net
// --------------------------

#include <windows.h>	// needed for winmain.h
#include "system.h"
#include "winmain.h"	// declares HDC and HWND

void SysShutdown (void)
{
	wglMakeCurrent(hdc, NULL);		// release device context in use by rc
	wglDeleteContext(hglrc);		// delete rendering context

	PostQuitMessage(0);				// make sure the window will be destroyed

	if (screenmode == FULLSCREEN)	// if FULLSCREEN, change back to original resolution
		SysRecoverDisplayMode();
}

void SysSetDisplayMode (int width, int height, int depth)
{	
	DEVMODE dmode;
	
	memset(&dmode, 0, sizeof(DEVMODE));
	dmode.dmSize=sizeof(DEVMODE);
	dmode.dmPelsWidth = width;
	dmode.dmPelsHeight = height;
	dmode.dmBitsPerPel = depth;
	dmode.dmFields = DM_PELSWIDTH|DM_PELSHEIGHT|DM_BITSPERPEL;
	
	// change resolution, if possible
	if (ChangeDisplaySettings(&dmode, CDS_FULLSCREEN) != DISP_CHANGE_SUCCESSFUL)
	{
		// if not... failed to change resolution

		screenmode = 0;	// this prevents SysShutdown from changing resolution back

		MessageBox(NULL, "Your system doesn't support this screen resolution", "Display Error", MB_OK);
		SysShutdown();
	}
}

void SysRecoverDisplayMode (void)
{
	ChangeDisplaySettings(NULL, 0);
}
