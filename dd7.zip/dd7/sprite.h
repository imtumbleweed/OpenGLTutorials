// sprite.h

#define MAXFRAMES 16

struct SPRITE
{
    float x, y, width, height;
    bool transparent;
    LPDIRECTDRAWSURFACE7 surface[MAXFRAMES];
};

void BltSprite(SPRITE *sprite, int num, int x, int y);
void BltSpriteT(SPRITE *sprite, int num, int x, int y);
void CreateSprite(SPRITE *sprite, int num, int width, int height, int x, int y, bool transparent);
