// THE PIXELS TUTORIALS
// www.thepixels.net
// by: Greg Damon
//     gregd@thepixels.net

#include <windows.h>
#include "resource.h"

#define WNDCLASSNAME "wndclass"

HDC hdc;
HWND hwnd;

bool quit = false;

int r, g, b;

//*=====================
//  The event handler
//*=====================

LRESULT CALLBACK WinProc (HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam)
{
	switch (msg)
	{
		
	case WM_CLOSE:
		{
			PostQuitMessage(0);
		} break;
		
	case WM_COMMAND:
		{
			switch(LOWORD(wparam))
			{
			case ID_Red:
				{
					r = 250;
					g = 0;
					b = 0;
				} break;
				
			case ID_Green:
				{
					r = 0;
					g = 250;
					b = 0;
				} break;
				
			case ID_Blue:
				{
					r = 0;
					g = 0;
					b = 250;
				} break;
				
			case ID_Exit:
				{
					quit = true;
				} break;
			}
		} break;
	}

	return DefWindowProc(hwnd, msg, wparam, lparam);
}

//*=====================
//  WinMain
//*=====================

int WINAPI WinMain (HINSTANCE hinstance,
		   HINSTANCE hprevinstance,
		   LPSTR lpcmdline,
		   int nshowcmd)
{
	MSG msg;
	WNDCLASSEX ex;

	ex.cbSize = sizeof(WNDCLASSEX);
	ex.style = CS_HREDRAW|CS_VREDRAW|CS_OWNDC;
	ex.lpfnWndProc = WinProc;
	ex.cbClsExtra = 0;
	ex.cbWndExtra = 0;
	ex.hInstance = hinstance;
	ex.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	ex.hCursor = LoadCursor(NULL, IDC_ARROW);
	ex.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
	ex.lpszMenuName = NULL;
	ex.lpszClassName = WNDCLASSNAME;
	ex.hIconSm = NULL;

	RegisterClassEx(&ex);

	// Create the window

	HMENU hmenu = LoadMenu(hinstance, MAKEINTRESOURCE(ID_Menu));

	hwnd = CreateWindowEx(NULL,
 			      WNDCLASSNAME,
			      "Window",
			      WS_OVERLAPPEDWINDOW,
			      0, 0,
			      300, 300,
			      NULL,
			      hmenu,
			      hinstance,
			      NULL);

	ShowWindow(hwnd, SW_SHOW);
	UpdateWindow(hwnd);

	// The message loop

	HDC hdc = GetDC(hwnd);

	while (!quit)
	{
		if (PeekMessage(&msg, NULL, NULL, NULL, PM_REMOVE))
		{
			if(msg.message == WM_QUIT)
				quit = true;
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}

		for (int i = 0; i < 1000; i++)
			SetPixel(hdc, rand()%300, rand()%300, RGB(r, g, b));
	}

	ReleaseDC(hwnd, hdc);

	return msg.lParam;
}
