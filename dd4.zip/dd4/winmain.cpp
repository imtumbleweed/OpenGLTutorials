// THE PIXELS TUTORIALS
// www.thepixels.net
// by: Greg Damon
//     gregd@thepixels.net

#include <windows.h>
#include <ddraw.h>

#define _15BIT(r,g,b) (((r&248)<<7) + ((g&248)<<2) + (b>>3))
#define _16BIT(r,g,b) (((r&248)<<8) + ((g&252)<<3) + (b>>3))

#define WNDCLASSNAME "wndclass"

typedef unsigned short ushort;

HDC hdc;
HWND hwnd;

DDSURFACEDESC2			ddsd;
LPDIRECTDRAW			lpdd = NULL;
LPDIRECTDRAW7			lpdd7 = NULL;
LPDIRECTDRAWSURFACE7	lpPrimary = NULL;

int swidth = 640;
int sheight = 480;
int sbpp = 16;

int lpitch = 0;
ushort *lpscreen = NULL;

bool quit = false;

//*=====================
//  Direct draw
//*=====================

void EraseDesc (void)
{
	memset(&ddsd, 0, sizeof(DDSURFACEDESC2));
	ddsd.dwSize = sizeof(DDSURFACEDESC2);
}

void DirectDrawRelease (void)
{
	if (lpPrimary)
	{
		lpPrimary->Release();
		lpPrimary = NULL;
	}

	if (lpdd7)
	{
		lpdd7->Release();
		lpdd7 = NULL;
	}
}

void DirectDrawInit (void)
{
	long rval;
	
	rval = DirectDrawCreate(NULL, &lpdd, NULL);

	if (rval != DD_OK)
	{
		MessageBox(hwnd, "Failed to create the DirectDraw object", "Error", MB_OK);
		quit = true;
	}
	
	rval = lpdd->QueryInterface(IID_IDirectDraw7, (LPVOID*)&lpdd7);

	if (rval != DD_OK)
	{
		MessageBox(hwnd, "Failed to query interface for DirectDraw7", "Error", MB_OK);
		quit = true;
	}
	
	if (lpdd)
	{
		lpdd->Release();
		lpdd = NULL;
	}
	
	rval = lpdd7->SetCooperativeLevel(hwnd, DDSCL_FULLSCREEN|DDSCL_EXCLUSIVE|DDSCL_ALLOWREBOOT);

	if (rval != DD_OK)
	{
		MessageBox(hwnd, "Failed to set DirectDraw cooperative level", "Error", MB_OK);
		quit = true;
	}
	
	rval = lpdd7->SetDisplayMode(swidth, sheight, sbpp, 0, 0);

	if (rval != DD_OK)
	{
		MessageBox(hwnd, "Failed to set display mode", "Error", MB_OK);
		quit = true;
	}

	EraseDesc();
	
	// set appropriate flags for creating the primary surface
	ddsd.dwFlags = DDSD_CAPS;
	ddsd.ddsCaps.dwCaps = DDSCAPS_PRIMARYSURFACE;
	
	rval = lpdd7->CreateSurface(&ddsd, &lpPrimary, NULL);
		
	if (rval != DD_OK)
	{
		MessageBox(hwnd, "Failed to create the primary surface", "Error", MB_OK);
		quit = true;
	}
}

void LockSurface (LPDIRECTDRAWSURFACE7 surface)
{
	EraseDesc();
	
	if ((surface->Lock(NULL, &ddsd, DDLOCK_WAIT, NULL)) != DD_OK)
		MessageBox(hwnd, "Failed to lock the surface", "Surface Error", MB_OK);

	lpitch = (int)ddsd.lPitch;
	lpscreen = (ushort*)ddsd.lpSurface;
}

void UnlockSurface (LPDIRECTDRAWSURFACE7 surface)
{
	surface->Unlock(NULL);
	
	lpitch = 0;
	lpscreen = NULL;
}

void Pixel (int x, int y, ushort color)
{
	lpscreen[x + y * (lpitch >> 1)] = color;
}

void Line (int x1, int y1, int x2, int y2, ushort color)
{
	int		dx,		//deltas
            dy,
            dx2,	//scaled deltas
            dy2,
            ix,		//increase rate on the x axis
            iy,		//increase rate on the y axis
            err,	//the error term
            i;		//looping variable

	int pitch = lpitch;

	// identify the first pixel
	ushort *ptr_vid = lpscreen + x1 + (y1 * (pitch >> 1));

	// difference between starting and ending points
	dx = x2 - x1;
	dy = y2 - y1;

	// calculate direction of the vector and store in ix and iy
	if (dx >= 0)
		ix = 1;

	if (dx < 0)
	{
		ix = -1;
		dx = abs(dx);
	}

	if (dy >= 0)
		iy = (pitch >> 1);

	if (dy < 0)
	{
		iy = -(pitch >> 1);
		dy = abs(dy);
	}

	// scale deltas and store in dx2 and dy2
	dx2 = dx * 2;
	dy2 = dy * 2;

	if (dx > dy)	// dx is the major axis
	{
		// initialize the error term
		err = dy2 - dx;

		for (i = 0; i <= dx; i++)
		{
			*ptr_vid = color;
			if (err >= 0)
			{
				err -= dx2;
				ptr_vid += iy;
			}
			err += dy2;
			ptr_vid += ix;
		}
	}
	
	else 		// dy is the major axis
	{
		// initialize the error term
		err = dx2 - dy;

		for (i = 0; i <= dy; i++)
		{
			*ptr_vid = color;
			if (err >= 0)
			{
				err -= dy2;
				ptr_vid += ix;
			}
			err += dx2;
			ptr_vid += iy;
		}
	}
} // end of void Line (...

//*=====================
//  The event handler
//*=====================

LRESULT CALLBACK WinProc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam)
{
	switch(msg)
	{
	case WM_CLOSE:
		{
			PostQuitMessage(0);
			break;
		}
	}
	return DefWindowProc(hwnd, msg, wparam, lparam);
}

//*=====================
//  WinMain
//*=====================

int WINAPI WinMain(HINSTANCE hinstance,
		   HINSTANCE hprevinstance,
		   LPSTR lpcmdline,
		   int nshowcmd)
{
	MSG msg;
	WNDCLASSEX ex;

	ex.cbSize = sizeof(WNDCLASSEX);
	ex.style = CS_HREDRAW|CS_VREDRAW|CS_OWNDC;
	ex.lpfnWndProc = WinProc;
	ex.cbClsExtra = 0;
	ex.cbWndExtra = 0;
	ex.hInstance = hinstance;
	ex.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	ex.hCursor = LoadCursor(NULL, IDC_ARROW);
	ex.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
	ex.lpszMenuName = NULL;
	ex.lpszClassName = WNDCLASSNAME;
	ex.hIconSm = NULL;

	RegisterClassEx(&ex);

	// Create the window

	hwnd = CreateWindowEx(NULL,
 			      WNDCLASSNAME,
			      "Window",
			      WS_POPUP,
			      0, 0,
			      300, 300,
			      NULL,
			      NULL,
			      hinstance,
			      NULL);

	ShowWindow(hwnd, SW_SHOW);
	UpdateWindow(hwnd);

	DirectDrawInit();

	// The message loop

	while(!quit)
	{
		if(PeekMessage(&msg, NULL, NULL, NULL, PM_REMOVE))
		{
			if(msg.message == WM_QUIT || GetAsyncKeyState(VK_ESCAPE))
				quit = true;

			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}

		LockSurface(lpPrimary);
		
		for (int i = 0; i < 100; i++)
			Line (rand()%639, rand()%479, rand()%639, rand()%479, (ushort)_16BIT(rand()%255, 0, rand()%255));
		
		UnlockSurface(lpPrimary);
	}

	DirectDrawRelease();

	return msg.lParam;
}
